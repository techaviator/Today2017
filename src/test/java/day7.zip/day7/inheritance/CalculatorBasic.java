package day7.inheritance;

public class CalculatorBasic {
	
	int x=100;
	int y= 200;
	int Result;
	
	protected int a=50;
	
	public void add(){
		Result = x+y;
	}
	

}
