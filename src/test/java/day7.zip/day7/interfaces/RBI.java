package day7.interfaces;

public interface RBI {	
	int x=10;
	public void setGoldLoanInterest();
	public void setFixedDeposit();
}
