package day5.methods.PassByReference;

public class Student {
	String name;
	int age ;

}
