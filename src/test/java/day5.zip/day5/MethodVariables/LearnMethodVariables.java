package day5.MethodVariables;

public class LearnMethodVariables {
	static int x =5;//global variable
	
	public static void getXVAlue()
	{
		//int x=10;//Local variable to method getXValue()
	}
	public static void main(String[] args) {
		System.out.println(x);
		System.out.println();
	}
	
	public static void add(int a, int b){//variable a and b are local variable to method add and the scope remains with the block
		
	}

}
