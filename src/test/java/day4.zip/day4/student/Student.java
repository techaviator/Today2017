package day4.student;

public class Student {
	String name;
	int phy;
	int che;
	int total;
	static String SCHOOLNAME ="St.Joseph";
	
	public void displayTotal()
	{
		System.out.println("Name= "+name+" phy= "+phy+" che= "+che+" Total= "+total+" schoolname= "+SCHOOLNAME);
	}
	

}
