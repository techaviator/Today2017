package day4.student;

public class Deb_Student {
	
	public static void main(String[] args) {
		Student deb=new Student();
		deb.name = "Debjyoti";
		deb.phy=10;
		deb.che=11;
		deb.total=21;
		deb.displayTotal();
	}

}
