package day4.student;

public class Gun_Student {
	
	public static void main(String[] args) {
		Student gun=new Student();
		gun.displayTotal();
		gun.name="gurmeen";
		gun.phy=13;
		gun.che=14;
		gun.total=27;
		gun.displayTotal();
	}

}
