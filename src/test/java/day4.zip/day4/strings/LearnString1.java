package day4.strings;

public class LearnString1 {
	
	String name =new String("TechAviator");
	
	public static void main(String[] args) {
		LearnString1 learnString1 = new LearnString1();
		System.out.println(learnString1.name);
		System.out.println(learnString1.name.length());
		System.out.println(learnString1.name.charAt(5));
	}

}
