package day8.arrays;

public class WrapperClass {
	
	public static void main(String[] args) {
		/*int x = 10;
		
		String w = String.valueOf(x);
		Integer y = Integer.parseInt(w);
		System.out.println(y);
		
		Object test = "123";
		System.out.println("Test"+"\t"+test);
		test = 123;
		
		System.out.println("Test"+"\t"+test);*/
		
		String s = "12";
		double parseDouble = Double.parseDouble(s);
		System.out.println(parseDouble);
	}

}
