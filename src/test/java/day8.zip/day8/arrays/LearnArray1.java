package day8.arrays;

public class LearnArray1 {
	
	public static void main(String[] args) {
		/*int[][] arr = new int[2][2];
		
		arr[0][0] = 5;
		arr[0][1] = 15;
		arr[1][0] = 25;
		arr[1][1] = 35;*/
		
		int[][] arr = {{10,20},{5,15,25,35}};
		
		/*for(int i =0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.println(arr[i][j]);
			}
		}*/
		
		
	}

}
